﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmirnovaTD.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int OrderNumber { get; set; }
        public int ArticleId { get; set; }
        public string ArticleName { get; set; }
        public int Count { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int AdressId { get; set; }
        public string AdressText { get; set; }
        public int UserId { get; set; }
        public string UserFio { get; set; }
        public int Code { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
    }
}
