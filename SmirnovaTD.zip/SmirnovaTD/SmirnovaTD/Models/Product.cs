﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmirnovaTD.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Article { get; set; }
        public string ProductName { get; set; }
        public int MeasurementId { get; set; }
        public string MeasurementName { get; set; }
        public decimal Price { get; set; }
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public int ManufacturerId { get; set; }
        public string ManufacturerName { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public decimal Discount { get; set; }
        public int Count { get; set; }
        public string DescriptionProduct { get; set; }
        public string Photo { get; set; }
    }
}
