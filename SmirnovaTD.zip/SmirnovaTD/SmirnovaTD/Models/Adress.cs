﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmirnovaTD.Models
{
    public class Adress
    {
        public int Id { get; set; }
        public string AdressText { get; set; }
    }
}
