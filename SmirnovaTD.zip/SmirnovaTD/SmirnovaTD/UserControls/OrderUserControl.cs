﻿using SmirnovaTD.Forms;
using SmirnovaTD.Models;
using SmirnovaTD.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmirnovaTD.UserControls
{
    public partial class OrderUserControl : UserControl
    {
        private Order order;

        public OrderUserControl(Order order)
        {
            InitializeComponent();
            this.order = order;
        }
               
        private void OrderUserControl_Load(object sender, EventArgs e)
        {
            try
            {
                if (order != null)
                {
                    lblId.Text = "ID: " + order.Id;
                    lblOrderNumber.Text = "Заказ #" + order.OrderNumber;
                    lblProduct.Text = "Товар: " + order.ArticleName + " x" + order.Count;
                    lblAdress.Text = "Адрес: " + order.AdressText;
                    lblOrderDate.Text = "Дата заказа: " + order.OrderDate.ToShortDateString();
                    lblDelivery.Text = "Дата выдачи: " + order.DeliveryDate.ToShortDateString();
                    lblStatus.Text = "Статус: " + order.StatusName;
                }

                btnDelete.Visible = ManagerService.IsAdmin();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказа: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PanelMain_Click(object sender, EventArgs e)
        {
            if (ManagerService.IsAdmin())
            {
                var form = new CreateUpdateOrder(order);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    ManagerService.OrderForm.LoadOrders();
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ManagerService.IsAdmin())
                {
                    MessageBox.Show("У вас недостаточно прав для этого действия",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DialogResult result = MessageBox.Show(
                    $"Вы уверены, что хотите удалить заказ #{order.OrderNumber}?",
                    "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    if (DatabaseHelper.DeleteOrder(order.Id))
                    {
                        MessageBox.Show("Заказ успешно удален", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ManagerService.OrderForm.LoadOrders();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}