﻿namespace SmirnovaTD.UserControls
{
    partial class OrderUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblDelivery;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblAdress;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblOrderNumber;
        private System.Windows.Forms.Label lblId;
        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMain = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblDelivery = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblAdress = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblOrderNumber = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();

            // OrderUserControl
            this.BackColor = System.Drawing.Color.White;
            this.Size = new System.Drawing.Size(780, 120);
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Load += new System.EventHandler(this.OrderUserControl_Load);

            // panelMain
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(245, 222, 179);
            this.panelMain.Controls.Add(this.btnDelete);
            this.panelMain.Controls.Add(this.lblStatus);
            this.panelMain.Controls.Add(this.lblDelivery);
            this.panelMain.Controls.Add(this.lblOrderDate);
            this.panelMain.Controls.Add(this.lblAdress);
            this.panelMain.Controls.Add(this.lblProduct);
            this.panelMain.Controls.Add(this.lblOrderNumber);
            this.panelMain.Controls.Add(this.lblId);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(5, 5);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(770, 110);
            this.panelMain.TabIndex = 0;
            this.panelMain.Click += new System.EventHandler(this.PanelMain_Click);

            // lblId
            this.lblId.Font = new System.Drawing.Font("Arial", 9F);
            this.lblId.Location = new System.Drawing.Point(10, 5);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(80, 20);
            this.lblId.TabIndex = 0;

            // lblOrderNumber
            this.lblOrderNumber.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.lblOrderNumber.Location = new System.Drawing.Point(10, 25);
            this.lblOrderNumber.Name = "lblOrderNumber";
            this.lblOrderNumber.Size = new System.Drawing.Size(150, 25);
            this.lblOrderNumber.TabIndex = 1;

            // lblProduct
            this.lblProduct.Font = new System.Drawing.Font("Arial", 10F);
            this.lblProduct.Location = new System.Drawing.Point(10, 50);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(200, 25);
            this.lblProduct.TabIndex = 2;

            // lblAdress
            this.lblAdress.Font = new System.Drawing.Font("Arial", 10F);
            this.lblAdress.Location = new System.Drawing.Point(220, 50);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(300, 25);
            this.lblAdress.TabIndex = 3;

            // lblOrderDate
            this.lblOrderDate.Font = new System.Drawing.Font("Arial", 10F);
            this.lblOrderDate.Location = new System.Drawing.Point(10, 75);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(200, 25);
            this.lblOrderDate.TabIndex = 4;

            // lblDelivery
            this.lblDelivery.Font = new System.Drawing.Font("Arial", 10F);
            this.lblDelivery.Location = new System.Drawing.Point(220, 75);
            this.lblDelivery.Name = "lblDelivery";
            this.lblDelivery.Size = new System.Drawing.Size(200, 25);
            this.lblDelivery.TabIndex = 5;

            // lblStatus
            this.lblStatus.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblStatus.ForeColor = System.Drawing.Color.Blue;
            this.lblStatus.Location = new System.Drawing.Point(430, 75);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(200, 25);
            this.lblStatus.TabIndex = 6;

            // btnDelete
            this.btnDelete.BackColor = System.Drawing.Color.LightCoral;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Arial", 9F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(680, 80);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 25);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);

            this.Controls.Add(this.panelMain);
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion
    }
}
