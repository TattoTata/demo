﻿using System.Windows.Forms;

namespace SmirnovaTD.UserControls
{
    partial class ProductUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.PictureBox picProduct;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblManufacturer;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblOldPrice;
        private System.Windows.Forms.Label lblMeasurement;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.Button btnDelete;
        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMain = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblMeasurement = new System.Windows.Forms.Label();
            this.lblOldPrice = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.lblManufacturer = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.picProduct = new System.Windows.Forms.PictureBox();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.White;
            this.panelMain.Controls.Add(this.picProduct);
            this.panelMain.Controls.Add(this.lblName);
            this.panelMain.Controls.Add(this.lblCategory);
            this.panelMain.Controls.Add(this.lblDescription);
            this.panelMain.Controls.Add(this.lblManufacturer);
            this.panelMain.Controls.Add(this.lblSupplier);
            this.panelMain.Controls.Add(this.lblPrice);
            this.panelMain.Controls.Add(this.lblOldPrice);
            this.panelMain.Controls.Add(this.lblMeasurement);
            this.panelMain.Controls.Add(this.lblCount);
            this.panelMain.Controls.Add(this.lblDiscount);
            this.panelMain.Controls.Add(this.btnDelete);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(5, 5);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1275, 143);
            this.panelMain.TabIndex = 0;
            this.panelMain.Click += new System.EventHandler(this.PanelMain_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.LightCoral;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Arial", 9F);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(846, 80);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 25);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // lblDiscount
            // 
            this.lblDiscount.BackColor = System.Drawing.Color.White;
            this.lblDiscount.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblDiscount.ForeColor = System.Drawing.Color.Green;
            this.lblDiscount.Location = new System.Drawing.Point(785, 50);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(120, 20);
            this.lblDiscount.TabIndex = 10;
            this.lblDiscount.Text = "0%";
            // 
            // lblCount
            // 
            this.lblCount.BackColor = System.Drawing.Color.White;
            this.lblCount.Font = new System.Drawing.Font("Arial", 10F);
            this.lblCount.Location = new System.Drawing.Point(785, 25);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(120, 20);
            this.lblCount.TabIndex = 9;
            // 
            // lblMeasurement
            // 
            this.lblMeasurement.BackColor = System.Drawing.Color.White;
            this.lblMeasurement.Font = new System.Drawing.Font("Arial", 10F);
            this.lblMeasurement.Location = new System.Drawing.Point(785, 5);
            this.lblMeasurement.Name = "lblMeasurement";
            this.lblMeasurement.Size = new System.Drawing.Size(120, 20);
            this.lblMeasurement.TabIndex = 8;
            // 
            // lblOldPrice
            // 
            this.lblOldPrice.BackColor = System.Drawing.Color.White;
            this.lblOldPrice.Font = new System.Drawing.Font("Arial", 11F);
            this.lblOldPrice.ForeColor = System.Drawing.Color.Red;
            this.lblOldPrice.Location = new System.Drawing.Point(551, 71);
            this.lblOldPrice.Name = "lblOldPrice";
            this.lblOldPrice.Size = new System.Drawing.Size(150, 25);
            this.lblOldPrice.TabIndex = 7;
            this.lblOldPrice.Text = "0 ₽";
            // 
            // lblPrice
            // 
            this.lblPrice.BackColor = System.Drawing.Color.White;
            this.lblPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.lblPrice.ForeColor = System.Drawing.Color.Black;
            this.lblPrice.Location = new System.Drawing.Point(551, 46);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(150, 25);
            this.lblPrice.TabIndex = 6;
            this.lblPrice.Text = "0 ₽";
            // 
            // lblSupplier
            // 
            this.lblSupplier.BackColor = System.Drawing.Color.White;
            this.lblSupplier.Font = new System.Drawing.Font("Arial", 10F);
            this.lblSupplier.Location = new System.Drawing.Point(541, 26);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(200, 20);
            this.lblSupplier.TabIndex = 5;
            // 
            // lblManufacturer
            // 
            this.lblManufacturer.BackColor = System.Drawing.Color.White;
            this.lblManufacturer.Font = new System.Drawing.Font("Arial", 10F);
            this.lblManufacturer.Location = new System.Drawing.Point(541, 5);
            this.lblManufacturer.Name = "lblManufacturer";
            this.lblManufacturer.Size = new System.Drawing.Size(200, 20);
            this.lblManufacturer.TabIndex = 4;
            // 
            // lblDescription
            // 
            this.lblDescription.BackColor = System.Drawing.Color.White;
            this.lblDescription.Font = new System.Drawing.Font("Arial", 9F);
            this.lblDescription.Location = new System.Drawing.Point(120, 50);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(400, 40);
            this.lblDescription.TabIndex = 3;
            // 
            // lblCategory
            // 
            this.lblCategory.BackColor = System.Drawing.Color.White;
            this.lblCategory.Font = new System.Drawing.Font("Arial", 10F);
            this.lblCategory.Location = new System.Drawing.Point(120, 30);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(200, 20);
            this.lblCategory.TabIndex = 2;
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.Color.White;
            this.lblName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.lblName.Location = new System.Drawing.Point(120, 5);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(400, 25);
            this.lblName.TabIndex = 1;
            // 
            // picProduct
            // 
            this.picProduct.BackColor = System.Drawing.Color.LightGray;
            this.picProduct.Location = new System.Drawing.Point(10, 5);
            this.picProduct.Name = "picProduct";
            this.picProduct.Size = new System.Drawing.Size(100, 100);
            this.picProduct.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picProduct.TabIndex = 0;
            this.picProduct.TabStop = false;
            // 
            // ProductUserControl
            // 
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.panelMain);
            this.Name = "ProductUserControl";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Size = new System.Drawing.Size(1285, 153);
            this.Load += new System.EventHandler(this.ProductUserControl_Load);
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
