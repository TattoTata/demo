﻿using SmirnovaTD.Forms;
using SmirnovaTD.Models;
using SmirnovaTD.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SmirnovaTD.UserControls
{
    public partial class ProductUserControl : UserControl
    {
        private Product product;
        private decimal finalPrice;

        public ProductUserControl(Product product)
        {
            InitializeComponent();
            this.product = product;
        }

        private void ProductUserControl_Load(object sender, EventArgs e)
        {
            try
            {
                if (product.Discount > 17)
                {
                    panelMain.BackColor = Color.FromArgb(255, 222, 173);
                }

                if (product.Count == 0)
                {
                    panelMain.BackColor = Color.LightBlue;
                }

                lblName.Text = product.ProductName;
                lblCategory.Text = "Категория: " + product.CategoryName;
                lblDescription.Text = product.DescriptionProduct;
                lblManufacturer.Text = "Производитель: " + product.ManufacturerName;
                lblSupplier.Text = "Поставщик: " + product.SupplierName;
                lblMeasurement.Text = "Ед. изм.: " + product.MeasurementName;
                lblCount.Text = "Кол-во: " + product.Count;
                lblDiscount.Text = product.Discount + "%";

                if (product.Discount > 0)
                {
                    finalPrice = product.Price * (1 - product.Discount / 100);
                    lblOldPrice.Text = product.Price.ToString("F2") + " ₽";
                    lblOldPrice.Visible = true;
                    lblPrice.Text = finalPrice.ToString("F2") + " ₽";
                }
                else
                {
                    lblPrice.Text = product.Price.ToString("F2") + " ₽";
                    lblOldPrice.Visible = false;
                }

                LoadImage();
                btnDelete.Visible = ManagerService.IsAdmin();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки товара: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadImage()
        {
            try
            {
                if (!string.IsNullOrEmpty(product.Photo))
                {
                    string imagePath = PhotoService.GetImagePath(product.Photo);
                    if (File.Exists(imagePath))
                    {
                        picProduct.Image = Image.FromFile(imagePath);
                        return;
                    }
                }
                picProduct.Image = PhotoService.GetDefaultImage();
            }
            catch
            {
                picProduct.Image = PhotoService.GetDefaultImage();
            }
        }

        private void PanelMain_Click(object sender, EventArgs e)
        {
            if (ManagerService.IsAdmin())
            {
                var form = new CreateUpdateProduct(product);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    ManagerService.ProductForm.LoadProducts();
                }
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ManagerService.IsAdmin())
                {
                    MessageBox.Show("У вас недостаточно прав для этого действия",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                bool hasOrders = false;
                var orders = DatabaseHelper.GetOrders();
                foreach (DataRow row in orders.Rows)
                {
                    if (Convert.ToInt32(row["article_id"]) == product.Id)
                    {
                        hasOrders = true;
                        break;
                    }
                }

                if (hasOrders)
                {
                    MessageBox.Show("Товар присутствует в заказах и не может быть удален",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DialogResult result = MessageBox.Show(
                    $"Вы уверены, что хотите удалить товар \"{product.ProductName}\"?",
                    "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    if (!string.IsNullOrEmpty(product.Photo))
                    {
                        PhotoService.DeleteImage(product.Photo);
                    }

                    if (DatabaseHelper.DeleteProduct(product.Id))
                    {
                        MessageBox.Show("Товар успешно удален", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ManagerService.ProductForm.LoadProducts();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}