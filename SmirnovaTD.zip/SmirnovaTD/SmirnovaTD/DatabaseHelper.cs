﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;
using SmirnovaTD.Models;

namespace SmirnovaTD
{
    public static class DatabaseHelper
    {
        private static string connectionString = @"Data Source=localhost\MSSQLSERVER01;Initial Catalog=ToyStoreDB1111;Integrated Security=True;TrustServerCertificate=True";

        public static void SetConnectionString(string connString)
        {
            connectionString = connString;
        }

        private static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        #region Users
        public static User AuthenticateUser(string login, string password)
        {
            string query = @"
                SELECT u.*, ur.role_name 
                FROM [User] u
                JOIN UserRole ur ON u.role_id = ur.id
                WHERE u.login = @Login AND u.password = @Password";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Login", login);
                cmd.Parameters.AddWithValue("@Password", password);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new User
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            RoleId = Convert.ToInt32(reader["role_id"]),
                            RoleName = reader["role_name"].ToString(),
                            Fio = reader["fio"].ToString(),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString()
                        };
                    }
                    return null;
                }
            }
        }

        public static List<User> GetUsers()
        {
            List<User> users = new List<User>();
            string query = "SELECT * FROM [User]";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            RoleId = Convert.ToInt32(reader["role_id"]),
                            Fio = reader["fio"].ToString(),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString()
                        });
                    }
                }
            }
            return users;
        }
        #endregion

        #region Categories
        public static List<Category> GetCategories()
        {
            List<Category> categories = new List<Category>();
            string query = "SELECT id, category_name FROM ProductCategory ORDER BY category_name";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            CategoryName = reader["category_name"].ToString()
                        });
                    }
                }
            }
            return categories;
        }

        public static int GetCategoryId(string categoryName)
        {
            if (string.IsNullOrEmpty(categoryName)) return 0;
            string query = "SELECT id FROM ProductCategory WHERE category_name = @CategoryName";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@CategoryName", categoryName);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region Suppliers
        public static List<Supplier> GetSuppliers()
        {
            List<Supplier> suppliers = new List<Supplier>();
            string query = "SELECT id, supplier_name FROM Supplier ORDER BY supplier_name";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        suppliers.Add(new Supplier
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            SupplierName = reader["supplier_name"].ToString()
                        });
                    }
                }
            }
            return suppliers;
        }

        public static int GetSupplierId(string supplierName)
        {
            if (string.IsNullOrEmpty(supplierName)) return 0;
            string query = "SELECT id FROM Supplier WHERE supplier_name = @SupplierName";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@SupplierName", supplierName);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region Manufacturers
        public static List<Manufacturer> GetManufacturers()
        {
            List<Manufacturer> manufacturers = new List<Manufacturer>();
            string query = "SELECT id, manufacturer_name FROM Manufacturer ORDER BY manufacturer_name";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        manufacturers.Add(new Manufacturer
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            ManufacturerName = reader["manufacturer_name"].ToString()
                        });
                    }
                }
            }
            return manufacturers;
        }

        public static int GetManufacturerId(string manufacturerName)
        {
            if (string.IsNullOrEmpty(manufacturerName)) return 0;
            string query = "SELECT id FROM Manufacturer WHERE manufacturer_name = @ManufacturerName";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ManufacturerName", manufacturerName);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region Measurements
        public static List<Measurement> GetMeasurements()
        {
            List<Measurement> measurements = new List<Measurement>();
            string query = "SELECT id, measurement_name FROM Measurement ORDER BY measurement_name";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        measurements.Add(new Measurement
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            MeasurementName = reader["measurement_name"].ToString()
                        });
                    }
                }
            }
            return measurements;
        }

        public static int GetMeasurementId(string measurementName)
        {
            if (string.IsNullOrEmpty(measurementName)) return 0;
            string query = "SELECT id FROM Measurement WHERE measurement_name = @MeasurementName";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@MeasurementName", measurementName);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region Adresses
        public static List<Adress> GetAdresses()
        {
            List<Adress> adresses = new List<Adress>();
            string query = "SELECT id, adress FROM Adress ORDER BY adress";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        adresses.Add(new Adress
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            AdressText = reader["adress"].ToString()
                        });
                    }
                }
            }
            return adresses;
        }

        public static int GetAdressId(string adressText)
        {
            if (string.IsNullOrEmpty(adressText)) return 0;
            string query = "SELECT id FROM Adress WHERE adress = @Adress";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Adress", adressText);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region OrderStatuses
        public static List<OrderStatus> GetOrderStatuses()
        {
            List<OrderStatus> statuses = new List<OrderStatus>();
            string query = "SELECT id, status_name FROM OrderStatus ORDER BY status_name";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        statuses.Add(new OrderStatus
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            StatusName = reader["status_name"].ToString()
                        });
                    }
                }
            }
            return statuses;
        }

        public static int GetOrderStatusId(string statusName)
        {
            if (string.IsNullOrEmpty(statusName)) return 0;
            string query = "SELECT id FROM OrderStatus WHERE status_name = @StatusName";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@StatusName", statusName);
                conn.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
        #endregion

        #region Products
        public static DataTable GetProducts(string filter = "", string search = "", string sortColumn = "", string sortDirection = "ASC")
        {
            DataTable dt = new DataTable();
            string query = @"
                SELECT 
                    p.id,
                    p.article,
                    p.product_name,
                    pc.category_name,
                    p.description_product,
                    m.manufacturer_name,
                    s.supplier_name,
                    p.price,
                    me.measurement_name,
                    p.count,
                    p.discount,
                    p.photo
                FROM Product p
                LEFT JOIN ProductCategory pc ON p.category_id = pc.id
                LEFT JOIN Manufacturer m ON p.manufacturer_id = m.id
                LEFT JOIN Supplier s ON p.supplier_id = s.id
                LEFT JOIN Measurement me ON p.measurement_id = me.id
                WHERE 1=1";

            if (!string.IsNullOrEmpty(search))
            {
                query += " AND (p.product_name LIKE @Search OR p.article LIKE @Search OR pc.category_name LIKE @Search OR m.manufacturer_name LIKE @Search OR s.supplier_name LIKE @Search)";
            }
            if (!string.IsNullOrEmpty(filter) && filter != "Все поставщики")
            {
                query += " AND s.supplier_name = @Filter";
            }
            if (!string.IsNullOrEmpty(sortColumn))
            {
                string safeColumn = sortColumn.Replace("'", "");
                query += $" ORDER BY {safeColumn} {sortDirection}";
            }

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                if (!string.IsNullOrEmpty(search))
                {
                    cmd.Parameters.AddWithValue("@Search", "%" + search + "%");
                }
                if (!string.IsNullOrEmpty(filter) && filter != "Все поставщики")
                {
                    cmd.Parameters.AddWithValue("@Filter", filter);
                }
                conn.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public static bool AddProduct(Product product)
        {
            string query = @"
                INSERT INTO Product 
                (article, product_name, measurement_id, price, supplier_id, manufacturer_id, category_id, discount, count, description_product, photo)
                VALUES 
                (@Article, @ProductName, @MeasurementId, @Price, @SupplierId, @ManufacturerId, @CategoryId, @Discount, @Count, @DescriptionProduct, @Photo)";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Article", product.Article);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@MeasurementId", product.MeasurementId);
                cmd.Parameters.AddWithValue("@Price", product.Price);
                cmd.Parameters.AddWithValue("@SupplierId", product.SupplierId);
                cmd.Parameters.AddWithValue("@ManufacturerId", product.ManufacturerId);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.Parameters.AddWithValue("@Discount", product.Discount);
                cmd.Parameters.AddWithValue("@Count", product.Count);
                cmd.Parameters.AddWithValue("@DescriptionProduct", product.DescriptionProduct);
                cmd.Parameters.AddWithValue("@Photo", string.IsNullOrEmpty(product.Photo) ? DBNull.Value : (object)product.Photo);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static bool UpdateProduct(Product product)
        {
            string query = @"
                UPDATE Product SET 
                    article = @Article,
                    product_name = @ProductName,
                    measurement_id = @MeasurementId,
                    price = @Price,
                    supplier_id = @SupplierId,
                    manufacturer_id = @ManufacturerId,
                    category_id = @CategoryId,
                    discount = @Discount,
                    count = @Count,
                    description_product = @DescriptionProduct,
                    photo = @Photo
                WHERE id = @ProductId";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ProductId", product.Id);
                cmd.Parameters.AddWithValue("@Article", product.Article);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@MeasurementId", product.MeasurementId);
                cmd.Parameters.AddWithValue("@Price", product.Price);
                cmd.Parameters.AddWithValue("@SupplierId", product.SupplierId);
                cmd.Parameters.AddWithValue("@ManufacturerId", product.ManufacturerId);
                cmd.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                cmd.Parameters.AddWithValue("@Discount", product.Discount);
                cmd.Parameters.AddWithValue("@Count", product.Count);
                cmd.Parameters.AddWithValue("@DescriptionProduct", product.DescriptionProduct);
                cmd.Parameters.AddWithValue("@Photo", string.IsNullOrEmpty(product.Photo) ? DBNull.Value : (object)product.Photo);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static bool DeleteProduct(int productId)
        {
            // Проверка, есть ли товар в заказах
            string checkQuery = "SELECT COUNT(*) FROM [Order] WHERE article_id = @ProductId";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
            {
                checkCmd.Parameters.AddWithValue("@ProductId", productId);
                conn.Open();
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                if (count > 0)
                {
                    return false;
                }
            }

            string query = "DELETE FROM Product WHERE id = @ProductId";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ProductId", productId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static Product GetProductById(int productId)
        {
            string query = @"
                SELECT 
                    p.id,
                    p.article,
                    p.product_name,
                    p.measurement_id,
                    me.measurement_name,
                    p.price,
                    p.supplier_id,
                    s.supplier_name,
                    p.manufacturer_id,
                    m.manufacturer_name,
                    p.category_id,
                    pc.category_name,
                    p.discount,
                    p.count,
                    p.description_product,
                    p.photo
                FROM Product p
                LEFT JOIN ProductCategory pc ON p.category_id = pc.id
                LEFT JOIN Manufacturer m ON p.manufacturer_id = m.id
                LEFT JOIN Supplier s ON p.supplier_id = s.id
                LEFT JOIN Measurement me ON p.measurement_id = me.id
                WHERE p.id = @ProductId";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ProductId", productId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Product
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Article = reader["article"].ToString(),
                            ProductName = reader["product_name"].ToString(),
                            MeasurementId = Convert.ToInt32(reader["measurement_id"]),
                            MeasurementName = reader["measurement_name"]?.ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            SupplierId = Convert.ToInt32(reader["supplier_id"]),
                            SupplierName = reader["supplier_name"]?.ToString(),
                            ManufacturerId = Convert.ToInt32(reader["manufacturer_id"]),
                            ManufacturerName = reader["manufacturer_name"]?.ToString(),
                            CategoryId = Convert.ToInt32(reader["category_id"]),
                            CategoryName = reader["category_name"]?.ToString(),
                            Discount = Convert.ToDecimal(reader["discount"]),
                            Count = Convert.ToInt32(reader["count"]),
                            DescriptionProduct = reader["description_product"]?.ToString(),
                            Photo = reader["photo"]?.ToString()
                        };
                    }
                    return null;
                }
            }
        }

        public static int GetProductCount()
        {
            string query = "SELECT COUNT(*) FROM Product";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }
        #endregion

        #region Orders
        public static DataTable GetOrders()
        {
            DataTable dt = new DataTable();
            string query = @"
                SELECT 
                    o.id,
                    o.order_number,
                    p.product_name as article_name,
                    o.count,
                    o.order_date,
                    o.delivery_date,
                    a.adress as adress_text,
                    u.fio as user_fio,
                    o.code,
                    os.status_name
                FROM [Order] o
                JOIN Product p ON o.article_id = p.id
                JOIN Adress a ON o.adress_id = a.id
                JOIN [User] u ON o.user_id = u.id
                JOIN OrderStatus os ON o.status_id = os.id
                ORDER BY o.order_date DESC";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }

        public static bool AddOrder(Order order)
        {
            string query = @"
                INSERT INTO [Order] 
                (order_number, article_id, count, order_date, delivery_date, adress_id, user_id, code, status_id)
                VALUES 
                (@OrderNumber, @ArticleId, @Count, @OrderDate, @DeliveryDate, @AdressId, @UserId, @Code, @StatusId)";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@OrderNumber", order.OrderNumber);
                cmd.Parameters.AddWithValue("@ArticleId", order.ArticleId);
                cmd.Parameters.AddWithValue("@Count", order.Count);
                cmd.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                cmd.Parameters.AddWithValue("@DeliveryDate", order.DeliveryDate);
                cmd.Parameters.AddWithValue("@AdressId", order.AdressId);
                cmd.Parameters.AddWithValue("@UserId", order.UserId);
                cmd.Parameters.AddWithValue("@Code", order.Code);
                cmd.Parameters.AddWithValue("@StatusId", order.StatusId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static bool UpdateOrder(Order order)
        {
            string query = @"
                UPDATE [Order] SET 
                    order_number = @OrderNumber,
                    article_id = @ArticleId,
                    count = @Count,
                    order_date = @OrderDate,
                    delivery_date = @DeliveryDate,
                    adress_id = @AdressId,
                    user_id = @UserId,
                    code = @Code,
                    status_id = @StatusId
                WHERE id = @OrderId";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@OrderId", order.Id);
                cmd.Parameters.AddWithValue("@OrderNumber", order.OrderNumber);
                cmd.Parameters.AddWithValue("@ArticleId", order.ArticleId);
                cmd.Parameters.AddWithValue("@Count", order.Count);
                cmd.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                cmd.Parameters.AddWithValue("@DeliveryDate", order.DeliveryDate);
                cmd.Parameters.AddWithValue("@AdressId", order.AdressId);
                cmd.Parameters.AddWithValue("@UserId", order.UserId);
                cmd.Parameters.AddWithValue("@Code", order.Code);
                cmd.Parameters.AddWithValue("@StatusId", order.StatusId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static bool DeleteOrder(int orderId)
        {
            string query = "DELETE FROM [Order] WHERE id = @OrderId";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public static Order GetOrderById(int orderId)
        {
            string query = @"
                SELECT 
                    o.id,
                    o.order_number,
                    o.article_id,
                    p.product_name as article_name,
                    o.count,
                    o.order_date,
                    o.delivery_date,
                    o.adress_id,
                    a.adress as adress_text,
                    o.user_id,
                    u.fio as user_fio,
                    o.code,
                    o.status_id,
                    os.status_name
                FROM [Order] o
                JOIN Product p ON o.article_id = p.id
                JOIN Adress a ON o.adress_id = a.id
                JOIN [User] u ON o.user_id = u.id
                JOIN OrderStatus os ON o.status_id = os.id
                WHERE o.id = @OrderId";

            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@OrderId", orderId);
                conn.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Order
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            OrderNumber = Convert.ToInt32(reader["order_number"]),
                            ArticleId = Convert.ToInt32(reader["article_id"]),
                            ArticleName = reader["article_name"].ToString(),
                            Count = Convert.ToInt32(reader["count"]),
                            OrderDate = Convert.ToDateTime(reader["order_date"]),
                            DeliveryDate = Convert.ToDateTime(reader["delivery_date"]),
                            AdressId = Convert.ToInt32(reader["adress_id"]),
                            AdressText = reader["adress_text"].ToString(),
                            UserId = Convert.ToInt32(reader["user_id"]),
                            UserFio = reader["user_fio"].ToString(),
                            Code = Convert.ToInt32(reader["code"]),
                            StatusId = Convert.ToInt32(reader["status_id"]),
                            StatusName = reader["status_name"].ToString()
                        };
                    }
                    return null;
                }
            }
        }

        public static int GetNextOrderNumber()
        {
            string query = "SELECT ISNULL(MAX(order_number), 0) + 1 FROM [Order]";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public static int GetNextCode()
        {
            string query = "SELECT ISNULL(MAX(code), 0) + 1 FROM [Order]";
            using (SqlConnection conn = GetConnection())
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }
        #endregion

        #region Check Database
        public static bool DatabaseExists()
        {
            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
}
