﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmirnovaTD.Forms;
using SmirnovaTD.Models;

namespace SmirnovaTD.Services
{
    public static class ManagerService
    {
        public static User CurrentUser { get; set; }
        public static ProductForm ProductForm { get; set; }
        public static AuthForm AuthForm { get; set; }
        public static OrderForm OrderForm { get; set; }

        public static bool IsAdmin()
        {
            return CurrentUser?.RoleName == "Администратор";
        }

        public static bool IsManager()
        {
            return CurrentUser?.RoleName == "Менеджер";
        }

        public static bool IsClient()
        {
            return CurrentUser?.RoleName == "Авторизированный клиент";
        }

        public static bool IsGuest()
        {
            return CurrentUser == null || CurrentUser.Id == 0;
        }

        public static bool CanEditProducts()
        {
            return IsAdmin();
        }

        public static bool CanViewOrders()
        {
            return IsManager() || IsAdmin();
        }

        public static bool CanEditOrders()
        {
            return IsAdmin();
        }
    }
}