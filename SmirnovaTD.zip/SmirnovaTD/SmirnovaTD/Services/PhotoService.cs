﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmirnovaTD.Forms;
using SmirnovaTD.Models;
using System.Windows.Forms;

namespace SmirnovaTD.Services
{
    public static class PhotoService
    {
        private static string GetImageFolder()
        {
            string folder = Path.Combine(Application.StartupPath, "Images");
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            return folder;
        }

        public static string GetImagePath(string imageName)
        {
            return Path.Combine(GetImageFolder(), imageName);
        }

        public static void DeleteImage(string imageName)
        {
            if (string.IsNullOrEmpty(imageName)) return;
            string path = GetImagePath(imageName);
            if (File.Exists(path))
            {
                try { File.Delete(path); } catch { }
            }
        }

        public static string SaveImage(string sourcePath)
        {
            if (string.IsNullOrEmpty(sourcePath) || !File.Exists(sourcePath))
                return null;

            try
            {
                using (Image original = Image.FromFile(sourcePath))
                {
                    // Изменяем размер до 300x200
                    int width = 300;
                    int height = 200;
                    float ratio = Math.Min((float)width / original.Width, (float)height / original.Height);
                    int newWidth = (int)(original.Width * ratio);
                    int newHeight = (int)(original.Height * ratio);

                    using (Bitmap resized = new Bitmap(newWidth, newHeight))
                    {
                        using (Graphics g = Graphics.FromImage(resized))
                        {
                            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                            g.DrawImage(original, 0, 0, newWidth, newHeight);
                        }

                        string fileName = Guid.NewGuid().ToString().Substring(0, 8) + ".jpg";
                        string fullPath = GetImagePath(fileName);
                        resized.Save(fullPath, ImageFormat.Jpeg);
                        return fileName;
                    }
                }
            }
            catch
            {
                return null;
            }
        }

        public static Image GetDefaultImage()
        {
            // Проверяем наличие файла заглушки
            string defaultPath = GetImagePath("picture.png");
            if (File.Exists(defaultPath))
            {
                try
                {
                    return Image.FromFile(defaultPath);
                }
                catch { }
            }

            // Создаем заглушку
            Bitmap bmp = new Bitmap(100, 100);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.LightGray);
                g.DrawString("Нет фото", new Font("Arial", 10), Brushes.Gray, new PointF(20, 40));
            }
            return bmp;
        }
    }
}