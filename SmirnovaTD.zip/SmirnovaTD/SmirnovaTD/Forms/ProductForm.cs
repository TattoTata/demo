﻿using SmirnovaTD.Models;
using SmirnovaTD.Services;
using SmirnovaTD.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmirnovaTD.Forms
{
    public partial class ProductForm : Form
    {
        private DataTable productsData;
        private string currentSearch = "";
        private string currentFilter = "Все поставщики";

        public ProductForm()
        {
            InitializeComponent();
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            try
            {
                if (!DatabaseHelper.DatabaseExists())
                {
                    MessageBox.Show("База данных не найдена! Проверьте подключение.",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (ManagerService.CurrentUser != null)
                {
                    lblUserInfo.Text = ManagerService.CurrentUser.Fio;

                    if (ManagerService.IsAdmin())
                    {
                        btnAddProduct.Visible = true;
                        btnOrders.Visible = true;
                    }
                    else if (ManagerService.IsManager())
                    {
                        btnOrders.Visible = true;
                    }
                    else if (ManagerService.IsGuest())
                    {
                        lblUserInfo.Text = "Гость";
                        txtSearch.Enabled = false;
                        cmbFilter.Enabled = false;
                        rbMoreCount.Enabled = false;
                        rbLessCount.Enabled = false;
                        rbMorePrice.Enabled = false;
                        rbLessPrice.Enabled = false;
                    }
                }

                LoadSuppliers();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки формы: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadSuppliers()
        {
            cmbFilter.Items.Clear();
            cmbFilter.Items.Add("Все поставщики");
            var suppliers = DatabaseHelper.GetSuppliers();
            foreach (var supplier in suppliers)
            {
                cmbFilter.Items.Add(supplier.SupplierName);
            }
            cmbFilter.SelectedIndex = 0;
        }

        public void LoadProducts()
        {
            try
            {
                flowLayoutPanel1.Controls.Clear();

                string sortColumn = "";
                string sortDirection = "ASC";

                if (rbMoreCount.Checked)
                { sortColumn = "count"; sortDirection = "ASC"; }
                else if (rbLessCount.Checked)
                { sortColumn = "count"; sortDirection = "DESC"; }
                else if (rbMorePrice.Checked)
                { sortColumn = "price"; sortDirection = "ASC"; }
                else if (rbLessPrice.Checked)
                { sortColumn = "price"; sortDirection = "DESC"; }

                productsData = DatabaseHelper.GetProducts(currentFilter, currentSearch, sortColumn, sortDirection);

                if (productsData.Rows.Count == 0)
                {
                    Label lblEmpty = new Label();
                    lblEmpty.Text = "Товары не найдены";
                    lblEmpty.Font = new Font("Arial", 14F);
                    lblEmpty.ForeColor = Color.Gray;
                    lblEmpty.AutoSize = true;
                    lblEmpty.Padding = new Padding(20);
                    flowLayoutPanel1.Controls.Add(lblEmpty);
                }
                else
                {
                    foreach (DataRow row in productsData.Rows)
                    {
                        Product product = new Product
                        {
                            Id = Convert.ToInt32(row["id"]),
                            Article = row["article"].ToString(),
                            ProductName = row["product_name"].ToString(),
                            CategoryName = row["category_name"]?.ToString(),
                            DescriptionProduct = row["description_product"]?.ToString(),
                            ManufacturerName = row["manufacturer_name"]?.ToString(),
                            SupplierName = row["supplier_name"]?.ToString(),
                            Price = Convert.ToDecimal(row["price"]),
                            MeasurementName = row["measurement_name"]?.ToString(),
                            Count = Convert.ToInt32(row["count"]),
                            Discount = Convert.ToDecimal(row["discount"]),
                            Photo = row["photo"]?.ToString()
                        };

                        var control = new ProductUserControl(product);
                        flowLayoutPanel1.Controls.Add(control);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки товаров: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            currentSearch = txtSearch.Text;
            LoadProducts();
        }

        private void CmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFilter.SelectedItem != null)
            {
                currentFilter = cmbFilter.SelectedItem.ToString();
                LoadProducts();
            }
        }

        private void Sort_CheckedChanged(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            var form = new CreateUpdateProduct();
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadProducts();
            }
        }

        private void BtnOrders_Click(object sender, EventArgs e)
        {
            if (ManagerService.OrderForm == null || ManagerService.OrderForm.IsDisposed)
            {
                ManagerService.OrderForm = new OrderForm();
            }
            ManagerService.OrderForm.Show();
            ManagerService.OrderForm.LoadOrders();
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы уверены, что хотите выйти?",
                "Выход", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                ManagerService.CurrentUser = null;
                this.Close();
                ManagerService.AuthForm.Show();
            }
        }
    }
}