﻿using SmirnovaTD.Models;
using SmirnovaTD.Services;
using SmirnovaTD.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmirnovaTD.Forms
{
    public partial class OrderForm : Form
    {
        private DataTable ordersData;

        public OrderForm()
        {
            InitializeComponent();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            try
            {
                if (ManagerService.IsAdmin())
                {
                    btnAddOrder.Visible = true;
                }

                LoadOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки формы: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadOrders()
        {
            try
            {
                flowLayoutPanel1.Controls.Clear();

                ordersData = DatabaseHelper.GetOrders();

                if (ordersData.Rows.Count == 0)
                {
                    Label lblEmpty = new Label();
                    lblEmpty.Text = "Заказы не найдены";
                    lblEmpty.Font = new Font("Arial", 14F);
                    lblEmpty.ForeColor = Color.Gray;
                    lblEmpty.AutoSize = true;
                    lblEmpty.Padding = new Padding(20);
                    flowLayoutPanel1.Controls.Add(lblEmpty);
                }
                else
                {
                    foreach (DataRow row in ordersData.Rows)
                    {
                        Order order = new Order
                        {
                            Id = Convert.ToInt32(row["id"]),
                            OrderNumber = Convert.ToInt32(row["order_number"]),
                            ArticleName = row["article_name"].ToString(),
                            Count = Convert.ToInt32(row["count"]),
                            OrderDate = Convert.ToDateTime(row["order_date"]),
                            DeliveryDate = Convert.ToDateTime(row["delivery_date"]),
                            AdressText = row["adress_text"].ToString(),
                            UserFio = row["user_fio"].ToString(),
                            Code = Convert.ToInt32(row["code"]),
                            StatusName = row["status_name"].ToString()
                        };

                        var control = new OrderUserControl(order);
                        flowLayoutPanel1.Controls.Add(control);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAddOrder_Click(object sender, EventArgs e)
        {
            var form = new CreateUpdateOrder();
            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadOrders();
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}