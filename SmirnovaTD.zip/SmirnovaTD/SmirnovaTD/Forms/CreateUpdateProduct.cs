﻿using SmirnovaTD.Models;
using SmirnovaTD.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SmirnovaTD.Forms
{
    public partial class CreateUpdateProduct : Form
    {
        private Product product;
        private bool isEditMode;
        private string errorString;

        public CreateUpdateProduct()
        {
            InitializeComponent();
            product = new Product
            {
                Article = GenerateArticle(),
                ProductName = string.Empty,
                DescriptionProduct = string.Empty,
                Photo = null
            };
            isEditMode = false;
        }

        public CreateUpdateProduct(Product existingProduct)
        {
            InitializeComponent();
            product = existingProduct;
            isEditMode = true;
        }

        private void CreateUpdateProduct_Load(object sender, EventArgs e)
        {
            try
            {
                // Загрузка данных в комбобоксы
                cmbCategory.DataSource = DatabaseHelper.GetCategories();
                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.ValueMember = "Id";

                cmbManufacturer.DataSource = DatabaseHelper.GetManufacturers();
                cmbManufacturer.DisplayMember = "ManufacturerName";
                cmbManufacturer.ValueMember = "Id";

                cmbSupplier.DataSource = DatabaseHelper.GetSuppliers();
                cmbSupplier.DisplayMember = "SupplierName";
                cmbSupplier.ValueMember = "Id";

                cmbMeasurement.DataSource = DatabaseHelper.GetMeasurements();
                cmbMeasurement.DisplayMember = "MeasurementName";
                cmbMeasurement.ValueMember = "Id";

                if (isEditMode && product != null)
                {
                    this.Text = "Редактирование товара";
                    lblTitle.Text = "Редактирование товара";

                    txtArticle.Text = product.Article;
                    txtArticle.Enabled = false;
                    txtName.Text = product.ProductName;
                    cmbCategory.SelectedValue = product.CategoryId;
                    txtDescription.Text = product.DescriptionProduct;
                    cmbManufacturer.SelectedValue = product.ManufacturerId;
                    cmbSupplier.SelectedValue = product.SupplierId;
                    numPrice.Value = product.Price;
                    cmbMeasurement.SelectedValue = product.MeasurementId;
                    numCount.Value = product.Count;
                    numDiscount.Value = product.Discount;

                    if (!string.IsNullOrEmpty(product.Photo))
                    {
                        string imagePath = PhotoService.GetImagePath(product.Photo);
                        if (File.Exists(imagePath))
                        {
                            try
                            {
                                picProduct.Image = Image.FromFile(imagePath);
                            }
                            catch { }
                        }
                    }
                }
                else
                {
                    numPrice.Value = 0;
                    numCount.Value = 0;
                    numDiscount.Value = 0;
                    if (cmbMeasurement.Items.Count > 0)
                        cmbMeasurement.SelectedIndex = 0;
                    txtArticle.Text = GenerateArticle();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки формы: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GenerateArticle()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            char[] result = new char[6];
            for (int i = 0; i < 6; i++)
            {
                result[i] = chars[random.Next(chars.Length)];
            }
            return new string(result);
        }

        private void BtnLoadImage_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                    openFileDialog.Title = "Выберите изображение";

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string fileName = PhotoService.SaveImage(openFileDialog.FileName);
                        if (!string.IsNullOrEmpty(fileName))
                        {
                            if (!string.IsNullOrEmpty(product.Photo))
                            {
                                PhotoService.DeleteImage(product.Photo);
                            }

                            product.Photo = fileName;
                            picProduct.Image = Image.FromFile(PhotoService.GetImagePath(fileName));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки изображения: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                ValidateData();

                if (!string.IsNullOrEmpty(errorString))
                {
                    MessageBox.Show(errorString, "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                GetData();

                bool result;
                if (isEditMode)
                {
                    result = DatabaseHelper.UpdateProduct(product);
                }
                else
                {
                    result = DatabaseHelper.AddProduct(product);
                }

                if (result)
                {
                    MessageBox.Show("Товар успешно сохранен!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ошибка сохранения товара.", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GetData()
        {
            product.Article = txtArticle.Text;
            product.ProductName = txtName.Text;
            product.CategoryId = (int)cmbCategory.SelectedValue;
            product.DescriptionProduct = txtDescription.Text;
            product.ManufacturerId = (int)cmbManufacturer.SelectedValue;
            product.SupplierId = (int)cmbSupplier.SelectedValue;
            product.Price = numPrice.Value;
            product.MeasurementId = (int)cmbMeasurement.SelectedValue;
            product.Count = (int)numCount.Value;
            product.Discount = numDiscount.Value;
        }

        private void ValidateData()
        {
            errorString = string.Empty;

            if (string.IsNullOrEmpty(txtArticle.Text))
                errorString += "\nВведите Артикул";

            if (string.IsNullOrEmpty(txtName.Text))
                errorString += "\nВведите наименование товара";

            if (cmbCategory.SelectedItem == null)
                errorString += "\nВыберите категорию";

            if (string.IsNullOrEmpty(txtDescription.Text))
                errorString += "\nВведите описание товара";

            if (cmbManufacturer.SelectedItem == null)
                errorString += "\nВыберите производителя";

            if (cmbSupplier.SelectedItem == null)
                errorString += "\nВыберите поставщика";

            if (cmbMeasurement.SelectedItem == null)
                errorString += "\nВыберите единицу измерения";

            if (numPrice.Value < 0)
                errorString += "\nЦена не может быть отрицательной";

            if (numCount.Value < 0)
                errorString += "\nКоличество не может быть отрицательным";

            if (numDiscount.Value < 0 || numDiscount.Value > 100)
                errorString += "\nСкидка должна быть от 0 до 100";
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}