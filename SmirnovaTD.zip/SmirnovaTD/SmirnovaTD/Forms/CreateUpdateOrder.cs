﻿using SmirnovaTD.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmirnovaTD.Forms
{
    public partial class CreateUpdateOrder : Form
    {
        private Order order;
        private bool isEditMode;
        private string errorString;

        public CreateUpdateOrder()
        {
            InitializeComponent();
            order = new Order
            {
                OrderNumber = DatabaseHelper.GetNextOrderNumber(),
                Count = 1,
                OrderDate = DateTime.Now,
                DeliveryDate = DateTime.Now.AddDays(7),
                Code = DatabaseHelper.GetNextCode()
            };
            isEditMode = false;
        }

        public CreateUpdateOrder(Order existingOrder)
        {
            InitializeComponent();
            order = existingOrder;
            isEditMode = true;
        }

        private void CreateUpdateOrder_Load(object sender, EventArgs e)
        {
            try
            {
                // Загрузка данных в комбобоксы
                var products = DatabaseHelper.GetProducts();
                cmbProduct.DataSource = products;
                cmbProduct.DisplayMember = "product_name";
                cmbProduct.ValueMember = "id";

                cmbAdress.DataSource = DatabaseHelper.GetAdresses();
                cmbAdress.DisplayMember = "AdressText";
                cmbAdress.ValueMember = "Id";

                cmbUser.DataSource = DatabaseHelper.GetUsers();
                cmbUser.DisplayMember = "Fio";
                cmbUser.ValueMember = "Id";

                cmbStatus.DataSource = DatabaseHelper.GetOrderStatuses();
                cmbStatus.DisplayMember = "StatusName";
                cmbStatus.ValueMember = "Id";

                if (isEditMode && order != null)
                {
                    this.Text = "Редактирование заказа";
                    lblTitle.Text = "Редактирование заказа";

                    txtOrderNumber.Text = order.OrderNumber.ToString();
                    cmbProduct.SelectedValue = order.ArticleId;
                    numCount.Value = order.Count;
                    dtpOrderDate.Value = order.OrderDate;
                    dtpDeliveryDate.Value = order.DeliveryDate;
                    cmbAdress.SelectedValue = order.AdressId;
                    cmbUser.SelectedValue = order.UserId;
                    cmbStatus.SelectedValue = order.StatusId;
                }
                else
                {
                    txtOrderNumber.Text = order.OrderNumber.ToString();
                    if (cmbStatus.Items.Count > 0)
                        cmbStatus.SelectedIndex = 0;
                    if (cmbUser.Items.Count > 0)
                        cmbUser.SelectedIndex = 0;
                    if (cmbAdress.Items.Count > 0)
                        cmbAdress.SelectedIndex = 0;
                    if (cmbProduct.Items.Count > 0)
                        cmbProduct.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки формы: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                ValidateData();

                if (!string.IsNullOrEmpty(errorString))
                {
                    MessageBox.Show(errorString, "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                GetData();

                bool result;
                if (isEditMode)
                {
                    result = DatabaseHelper.UpdateOrder(order);
                }
                else
                {
                    order.Code = DatabaseHelper.GetNextCode();
                    result = DatabaseHelper.AddOrder(order);
                }

                if (result)
                {
                    MessageBox.Show("Заказ успешно сохранен!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ошибка сохранения заказа.", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GetData()
        {
            order.OrderNumber = int.Parse(txtOrderNumber.Text);
            order.ArticleId = (int)cmbProduct.SelectedValue;
            order.Count = (int)numCount.Value;
            order.OrderDate = dtpOrderDate.Value.Date;
            order.DeliveryDate = dtpDeliveryDate.Value.Date;
            order.AdressId = (int)cmbAdress.SelectedValue;
            order.UserId = (int)cmbUser.SelectedValue;
            order.StatusId = (int)cmbStatus.SelectedValue;
        }

        private void ValidateData()
        {
            errorString = string.Empty;

            if (cmbProduct.SelectedItem == null)
                errorString += "\nВыберите товар";

            if (numCount.Value <= 0)
                errorString += "\nКоличество должно быть больше 0";

            if (cmbAdress.SelectedItem == null)
                errorString += "\nВыберите адрес выдачи";

            if (cmbUser.SelectedItem == null)
                errorString += "\nВыберите клиента";

            if (cmbStatus.SelectedItem == null)
                errorString += "\nВыберите статус";

            if (dtpDeliveryDate.Value < dtpOrderDate.Value)
                errorString += "\nДата выдачи не может быть раньше даты заказа";
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}