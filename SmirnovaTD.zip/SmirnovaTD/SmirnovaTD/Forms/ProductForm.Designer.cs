﻿using System.Windows.Forms;

namespace SmirnovaTD.Forms
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelSort;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblUserInfo;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnOrders;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.RadioButton rbMoreCount;
        private System.Windows.Forms.RadioButton rbLessCount;
        private System.Windows.Forms.RadioButton rbMorePrice;
        private System.Windows.Forms.RadioButton rbLessPrice;
        private System.Windows.Forms.Label lblSort;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.cmbFilter = new System.Windows.Forms.ComboBox();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnOrders = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblUserInfo = new System.Windows.Forms.Label();
            this.panelSort = new System.Windows.Forms.Panel();
            this.rbMoreCount = new System.Windows.Forms.RadioButton();
            this.rbLessCount = new System.Windows.Forms.RadioButton();
            this.rbMorePrice = new System.Windows.Forms.RadioButton();
            this.rbLessPrice = new System.Windows.Forms.RadioButton();
            this.lblSort = new System.Windows.Forms.Label();
            this.panelTop.SuspendLayout();
            this.panelSort.SuspendLayout();
            this.SuspendLayout();

            // ProductForm
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.Text = "МирИгрушек - Каталог товаров";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ProductForm_Load);

            // panelTop
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(245, 222, 179);
            this.panelTop.Controls.Add(this.lblUserInfo);
            this.panelTop.Controls.Add(this.btnLogout);
            this.panelTop.Controls.Add(this.btnOrders);
            this.panelTop.Controls.Add(this.btnAddProduct);
            this.panelTop.Controls.Add(this.cmbFilter);
            this.panelTop.Controls.Add(this.txtSearch);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height = 100;
            this.panelTop.Padding = new System.Windows.Forms.Padding(10);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(222, 184, 135);
            this.lblTitle.Location = new System.Drawing.Point(20, 10);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(174, 32);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "МирИгрушек";

            // lblUserInfo
            this.lblUserInfo.Font = new System.Drawing.Font("Arial", 11F);
            this.lblUserInfo.Location = new System.Drawing.Point(800, 10);
            this.lblUserInfo.Name = "lblUserInfo";
            this.lblUserInfo.Size = new System.Drawing.Size(200, 25);
            this.lblUserInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // btnLogout
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(222, 184, 135);
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Arial", 10F);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(900, 60);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(100, 25);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "Выйти";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.BtnLogout_Click);

            // btnOrders
            this.btnOrders.BackColor = System.Drawing.Color.FromArgb(222, 184, 135);
            this.btnOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrders.Font = new System.Drawing.Font("Arial", 10F);
            this.btnOrders.ForeColor = System.Drawing.Color.White;
            this.btnOrders.Location = new System.Drawing.Point(200, 60);
            this.btnOrders.Name = "btnOrders";
            this.btnOrders.Size = new System.Drawing.Size(120, 25);
            this.btnOrders.TabIndex = 1;
            this.btnOrders.Text = "Заказы";
            this.btnOrders.UseVisualStyleBackColor = false;
            this.btnOrders.Visible = false;
            this.btnOrders.Click += new System.EventHandler(this.BtnOrders_Click);

            // btnAddProduct
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(222, 184, 135);
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Font = new System.Drawing.Font("Arial", 10F);
            this.btnAddProduct.ForeColor = System.Drawing.Color.White;
            this.btnAddProduct.Location = new System.Drawing.Point(330, 60);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(150, 25);
            this.btnAddProduct.TabIndex = 2;
            this.btnAddProduct.Text = "Добавить товар";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Visible = false;
            this.btnAddProduct.Click += new System.EventHandler(this.BtnAddProduct_Click);

            // txtSearch
            this.txtSearch.Font = new System.Drawing.Font("Arial", 11F);
            this.txtSearch.Location = new System.Drawing.Point(20, 60);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(160, 25);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);

            // cmbFilter
            this.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilter.Font = new System.Drawing.Font("Arial", 11F);
            this.cmbFilter.Location = new System.Drawing.Point(620, 60);
            this.cmbFilter.Name = "cmbFilter";
            this.cmbFilter.Size = new System.Drawing.Size(180, 25);
            this.cmbFilter.TabIndex = 4;
            this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.CmbFilter_SelectedIndexChanged);

            // panelSort
            this.panelSort.BackColor = System.Drawing.Color.White;
            this.panelSort.Controls.Add(this.rbLessPrice);
            this.panelSort.Controls.Add(this.rbMorePrice);
            this.panelSort.Controls.Add(this.rbLessCount);
            this.panelSort.Controls.Add(this.rbMoreCount);
            this.panelSort.Controls.Add(this.lblSort);
            this.panelSort.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSort.Height = 40;
            this.panelSort.Padding = new System.Windows.Forms.Padding(10);

            // lblSort
            this.lblSort.AutoSize = true;
            this.lblSort.Font = new System.Drawing.Font("Arial", 10F);
            this.lblSort.Location = new System.Drawing.Point(20, 10);
            this.lblSort.Name = "lblSort";
            this.lblSort.Size = new System.Drawing.Size(80, 16);
            this.lblSort.TabIndex = 0;
            this.lblSort.Text = "Сортировка:";

            // rbMorePrice
            this.rbMorePrice.AutoSize = true;
            this.rbMorePrice.Font = new System.Drawing.Font("Arial", 10F);
            this.rbMorePrice.Location = new System.Drawing.Point(400, 10);
            this.rbMorePrice.Name = "rbMorePrice";
            this.rbMorePrice.Size = new System.Drawing.Size(112, 20);
            this.rbMorePrice.TabIndex = 1;
            this.rbMorePrice.Text = "Цена ↑";
            this.rbMorePrice.UseVisualStyleBackColor = true;
            this.rbMorePrice.CheckedChanged += new System.EventHandler(this.Sort_CheckedChanged);

            // rbLessPrice
            this.rbLessPrice.AutoSize = true;
            this.rbLessPrice.Font = new System.Drawing.Font("Arial", 10F);
            this.rbLessPrice.Location = new System.Drawing.Point(500, 10);
            this.rbLessPrice.Name = "rbLessPrice";
            this.rbLessPrice.Size = new System.Drawing.Size(112, 20);
            this.rbLessPrice.TabIndex = 2;
            this.rbLessPrice.Text = "Цена ↓";
            this.rbLessPrice.UseVisualStyleBackColor = true;
            this.rbLessPrice.CheckedChanged += new System.EventHandler(this.Sort_CheckedChanged);

            // rbMoreCount
            this.rbMoreCount.AutoSize = true;
            this.rbMoreCount.Font = new System.Drawing.Font("Arial", 10F);
            this.rbMoreCount.Location = new System.Drawing.Point(190, 10);
            this.rbMoreCount.Name = "rbMoreCount";
            this.rbMoreCount.Size = new System.Drawing.Size(94, 20);
            this.rbMoreCount.TabIndex = 3;
            this.rbMoreCount.Text = "Кол-во ↑";
            this.rbMoreCount.UseVisualStyleBackColor = true;
            this.rbMoreCount.CheckedChanged += new System.EventHandler(this.Sort_CheckedChanged);

            // rbLessCount
            this.rbLessCount.AutoSize = true;
            this.rbLessCount.Font = new System.Drawing.Font("Arial", 10F);
            this.rbLessCount.Location = new System.Drawing.Point(290, 10);
            this.rbLessCount.Name = "rbLessCount";
            this.rbLessCount.Size = new System.Drawing.Size(94, 20);
            this.rbLessCount.TabIndex = 4;
            this.rbLessCount.Text = "Кол-во ↓";
            this.rbLessCount.UseVisualStyleBackColor = true;
            this.rbLessCount.CheckedChanged += new System.EventHandler(this.Sort_CheckedChanged);

            // flowLayoutPanel1
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel1.WrapContents = false;

            this.panelTop.Controls.AddRange(new Control[] {
                this.lblTitle, this.lblUserInfo, this.btnLogout,
                this.btnOrders, this.btnAddProduct, this.txtSearch, this.cmbFilter
            });
            this.panelSort.Controls.AddRange(new Control[] {
                this.lblSort, this.rbMoreCount, this.rbLessCount,
                this.rbMorePrice, this.rbLessPrice
            });

            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panelSort);
            this.Controls.Add(this.panelTop);

            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelSort.ResumeLayout(false);
            this.panelSort.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion
    }
}