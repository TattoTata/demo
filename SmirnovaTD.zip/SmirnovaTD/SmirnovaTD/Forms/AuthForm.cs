﻿using SmirnovaTD.Models;
using SmirnovaTD.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmirnovaTD.Forms
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
            ManagerService.AuthForm = this;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string login = txtLogin.Text.Trim();
                string password = txtPassword.Text.Trim();

                if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Введите логин и пароль!", "Предупреждение",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Login(login, password);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка входа: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login(string login, string password)
        {
            try
            {
                // Проверка подключения к БД
                if (!DatabaseHelper.DatabaseExists())
                {
                    MessageBox.Show("База данных не найдена! Проверьте подключение.",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var user = DatabaseHelper.AuthenticateUser(login, password);

                if (user != null)
                {
                    ManagerService.CurrentUser = user;

                    var productForm = new ProductForm();
                    ManagerService.ProductForm = productForm;
                    this.Hide();
                    productForm.Show();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnGuest_Click(object sender, EventArgs e)
        {
            try
            {
                ManagerService.CurrentUser = new User
                {
                    Id = 0,
                    Fio = "Гость",
                    RoleName = "Гость"
                };

                var productForm = new ProductForm();
                ManagerService.ProductForm = productForm;
                this.Hide();
                productForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка входа как гость: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}